package customwidgets;

public class SearchboxData {
	public String text;
	public boolean isIgnoreCase;
}
