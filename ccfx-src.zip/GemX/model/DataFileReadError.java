package model;

public class DataFileReadError extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -351567073061572602L;

	public DataFileReadError(String message) {
	}
}
