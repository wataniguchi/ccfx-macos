package gemx;

public interface TextPaneScrollListener {
	public void textScrolled();
}
