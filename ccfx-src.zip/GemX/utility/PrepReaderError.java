package utility;

public class PrepReaderError extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2062184454509216802L;

	public PrepReaderError() {
	}
}
