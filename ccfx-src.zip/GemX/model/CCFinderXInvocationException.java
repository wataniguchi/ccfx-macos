package model;

public class CCFinderXInvocationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8262405048281004563L;

}
