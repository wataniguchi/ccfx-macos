package gemx;

public class ScopeHistoryItem {
	public String cloneDataFile;
	public String fileMetricFile;
	public String cloneSetMetricFile;
}

