package constants;

public class GemXDefaultSettings {
	public static final boolean initResizeScatterPlot = true;
	public static final boolean initCalcFileMetricAlways = false;
	public static final boolean initCalcCloneMetricAlways = false;
	public static final int initNtipleSourceTextPane = 2;
	public static final boolean initAllFileViewModeEnabled = false;
	public static final String initColorSchemeFile = "colors.json"; //$NON-NLS-1$
	public static final boolean initClonesetTableClickToShowPair = true;
	public static final boolean initResetScopeItemInContextMenus = false;
}
