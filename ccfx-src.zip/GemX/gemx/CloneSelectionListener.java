package gemx;

public interface CloneSelectionListener {
	public void setCloneSelection(long[] cloneSetIDS, CloneSelectionListener src);
}
