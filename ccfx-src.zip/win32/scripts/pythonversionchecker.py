#!/usr/bin/env python
# -*- encoding: utf-8 -*-

import sys

if __name__ == '__main__':
    version = sys.version_info[0:2]
    assert version >= (2, 6)
   
