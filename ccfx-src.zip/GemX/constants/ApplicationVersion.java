package constants;

public class ApplicationVersion {
	public static final int verMajor = 10;
	public static final int verMinor1 = 2;
	public static final int verMinor2 = 7;
	public static final int verFix = 4;
}
