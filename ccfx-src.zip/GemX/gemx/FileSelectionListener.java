package gemx;

public interface FileSelectionListener {
	public void setSelection(int[] fileIndex);
}
